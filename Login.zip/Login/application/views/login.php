<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<form action="<?php echo base_url()?>index.php/Welcome/login/" method="POST">
<input type="text" name="u" size="20" maxlengh="4" /> 
<input type="password" name="c" size="20" maxlengh="4" /> 
<BUTTON>Enviar</BUTTON>
</form>



</body>
</html>