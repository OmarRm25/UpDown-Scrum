<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
     public function __construct()
    {
        parent::__construct();
        $this->load->library('encrypt');
        $this->load->helper('url'); 
    }
	
	public function index()
	{
		$this->load->view('login.php');
	}
    public function login(){
    $this->load->model('Login_model');	
    $us= $this->input->get('u');
    $con = $this->input->get('c');
    $data['buscar'] = $this->login_model->buscar();
    echo $data;
    
}
    

   public function desencriptar($contra, $llave){
    $key=$llave;  // Una clave de codificacion, debe usarse la misma para encriptar y desencriptar
    $pass= rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($contra), MCRYPT_MODE_CBC, md5(md5($key))), "\0");
    return $pass;
   }
}
